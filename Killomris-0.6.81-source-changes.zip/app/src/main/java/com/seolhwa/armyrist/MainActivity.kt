package com.seolhwa.armyrist

import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.foundation.gestures.scrollBy
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.RestoreFromTrash
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.seolhwa.armyrist.data.CountingRepository
import com.seolhwa.armyrist.ui.DragMotion
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import com.seolhwa.armyrist.counting.reorder.CountingDragGeometry
import com.seolhwa.armyrist.counting.reorder.CountingReorderMode
import com.seolhwa.armyrist.counting.reorder.CountingReorderSlot
import com.seolhwa.armyrist.counting.reorder.CountingReorderV2
import com.seolhwa.armyrist.stage2.data.CoreSuiteRepository
import com.seolhwa.armyrist.stage2.domain.ToolResult
import com.seolhwa.armyrist.domain.*
import com.seolhwa.armyrist.voice.*
import com.seolhwa.armyrist.trash.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ArmyristApplication
        val repository = app.repository
        val coreSuiteRepository = app.coreSuiteRepository
        val trashRepository = app.commonTrashRepository

        setContent {
            ArmyristTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ArmyristColors.AppBackground
                ) {
                    ArmyristApp(
                        repo = repository,
                        coreRepo = coreSuiteRepository,
                        trashRepo = trashRepository,
                        onHome = { finish() }
                    )
                }
            }
        }
    }
}

private enum class Screen { SHEETS, COUNTING, GROUPS, CALCULATIONS, RESULT }
private enum class CountingViewMode { DETAILED, COMPACT }

@Composable
private fun ArmyristApp(
    repo: CountingRepository,
    coreRepo: CoreSuiteRepository,
    trashRepo: CommonTrashRepository,
    onHome: () -> Unit
) {
    var screenName by rememberSaveable { mutableStateOf(Screen.SHEETS.name) }
    val screen = runCatching { Screen.valueOf(screenName) }.getOrDefault(Screen.SHEETS)
    var selectedSheetId by rememberSaveable { mutableStateOf<String?>(null) }
    var revision by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val observedRevision = revision

    fun refresh() {
        revision++
    }

    when (screen) {
        Screen.SHEETS -> SheetListScreen(
            sheets = repo.getSheets(),
            trashRepo = trashRepo,
            onHome = onHome,
            onCreate = {
                val created = repo.createSheet()
                if (created != null) {
                    selectedSheetId = created.id
                    refresh()
                    screenName = Screen.COUNTING.name
                }
            },
            onOpen = {
                selectedSheetId = it
                screenName = Screen.COUNTING.name
            },
            onRename = { id, title ->
                if (repo.renameSheet(id, title)) refresh()
            },
            onDeleteToTrash = { id ->
                val current = repo.getSheet(id)
                val payload = repo.exportSheetTrashPayload(id)
                if (current == null || payload == null) {
                    false
                } else {
                    val trashItem = trashRepo.moveToTrash(
                        toolType = TrashToolType.COUNTING,
                        originalId = current.id,
                        title = current.title,
                        payloadVersion = 1,
                        payload = payload
                    )
                    if (trashItem == null) {
                        false
                    } else if (repo.deleteSheetForTrash(id)) {
                        refresh()
                        true
                    } else {
                        trashRepo.permanentlyDelete(trashItem.id)
                        false
                    }
                }
            },
            onRestoreTrash = { item ->
                if (repo.restoreSheetTrashPayload(item.payload)) {
                    trashRepo.permanentlyDelete(item.id)
                    refresh()
                    true
                } else false
            },
            onPermanentDeleteTrash = { item ->
                val deleted = trashRepo.permanentlyDelete(item.id)
                if (deleted) refresh()
                deleted
            }
        )

        else -> {
            val id = selectedSheetId
            val sheet = id?.let(repo::getSheet)

            if (sheet == null) {
                screenName = Screen.SHEETS.name
            } else {
                when (screen) {
                    Screen.COUNTING -> CountingScreen(
                        sheet = sheet,
                        onHome = onHome,
                        onBack = { screenName = Screen.SHEETS.name },
                        onAddGroup = { name, color, showAggregate ->
                            if (
                                repo.addGroup(
                                    sheet.id,
                                    name,
                                    color,
                                    showAggregate
                                )
                            ) refresh()
                        },
                        onRenameGroup = {
                            groupId,
                            name,
                            color,
                            showAggregate ->
                            if (
                                repo.renameGroup(
                                    sheet.id,
                                    groupId,
                                    name,
                                    color,
                                    showAggregate
                                )
                            ) refresh()
                        },
                        onDeleteGroup = {
                            repo.deleteGroup(sheet.id, it)
                            refresh()
                        },
                        onCalculations = { screenName = Screen.CALCULATIONS.name },
                        onResult = { screenName = Screen.RESULT.name },
                        onRename = {
                            if (repo.renameSheet(sheet.id, it)) refresh()
                        },
                        onMemo = {
                            repo.setMemo(sheet.id, it)
                            refresh()
                        },
                        onAddItem = { name, quantity, unit, note, groupId ->
                            if (repo.addItem(sheet.id, name, quantity, unit, note, groupId)) refresh()
                        },
                        onEditItem = { itemId, name, unit, note, groupId ->
                            if (repo.editItem(sheet.id, itemId, name, unit, note, groupId)) refresh()
                        },
                        onDeleteItem = {
                            repo.deleteItem(sheet.id, it)
                            refresh()
                        },
                        onIncrement = {
                            repo.increment(sheet.id, it)
                            refresh()
                        },
                        onDecrement = {
                            repo.decrement(sheet.id, it)
                            refresh()
                        },
                        onQuantity = { itemId, quantity ->
                            if (repo.setQuantity(sheet.id, itemId, quantity)) refresh()
                        },
                        onMove = { itemId, delta ->
                            repo.moveItem(sheet.id, itemId, delta)
                            refresh()
                        },
                        onReorder = { orderedIds ->
                            val saved = repo.reorderItems(sheet.id, orderedIds)
                            if (saved) refresh()
                            saved
                        },
                        onAssignGroup = { itemIds, groupId ->
                            if (repo.assignItemsToGroup(sheet.id, itemIds, groupId)) refresh()
                        }
                    )

                    Screen.GROUPS -> GroupScreen(
                        sheet = sheet,
                        onBack = { screenName = Screen.COUNTING.name },
                        onAdd = { name, color, showAggregate ->
                            if (
                                repo.addGroup(
                                    sheet.id,
                                    name,
                                    color,
                                    showAggregate
                                )
                            ) refresh()
                        },
                        onRename = {
                            groupId,
                            name,
                            color,
                            showAggregate ->
                            if (
                                repo.renameGroup(
                                    sheet.id,
                                    groupId,
                                    name,
                                    color,
                                    showAggregate
                                )
                            ) refresh()
                        },
                        onDelete = {
                            repo.deleteGroup(sheet.id, it)
                            refresh()
                        }
                    )

                    Screen.CALCULATIONS -> CalculationScreen(
                        sheet = sheet,
                        onBack = { screenName = Screen.COUNTING.name },
                        onAdd = { left, operator, right, name ->
                            if (repo.addCalculation(sheet.id, left, operator, right, name)) refresh()
                        },
                        onEdit = { calcId, left, operator, right, name ->
                            if (repo.editCalculation(sheet.id, calcId, left, operator, right, name)) refresh()
                        },
                        onDelete = {
                            repo.deleteCalculation(sheet.id, it)
                            refresh()
                        }
                    )

                    Screen.RESULT -> CommonShareScreen(
                        repo = coreRepo,
                        result = ToolResult(
                            title = sheet.title,
                            body = ResultGenerator.generate(sheet)
                        ),
                        onBack = { screenName = Screen.COUNTING.name },
                        portableType = ArmyristPortableDataType.COUNTING,
                        portableRootId = sheet.id
                    )

                    Screen.SHEETS -> Unit
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SheetListScreen(
    sheets: List<CountingSheet>,
    trashRepo: CommonTrashRepository,
    onHome: () -> Unit,
    onCreate: () -> Unit,
    onOpen: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDeleteToTrash: (String) -> Boolean,
    onRestoreTrash: (CommonTrashItem) -> Boolean,
    onPermanentDeleteTrash: (CommonTrashItem) -> Boolean
) {
    var renameTarget by remember { mutableStateOf<CountingSheet?>(null) }
    var deleteTarget by remember { mutableStateOf<CountingSheet?>(null) }
    var trashOpen by rememberSaveable { mutableStateOf(false) }
    var trashRevision by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val openImport = {
        context.startActivity(
            android.content.Intent(context, PortableTransferActivity::class.java).apply {
                putExtra(PortableTransferActivity.EXTRA_MODE, PortableTransferActivity.MODE_IMPORT)
            }
        )
    }

    if (trashOpen) {
        BackHandler { trashOpen = false }
        CommonTrashScreen(
            toolLabel = "실셈",
            items = trashRepo.getItems(TrashToolType.COUNTING),
            retentionDays = trashRepo.retentionDays(),
            onBack = { trashOpen = false },
            onRetentionChange = {
                if (trashRepo.setRetentionDays(it)) trashRevision++
            },
            onRestore = {
                if (onRestoreTrash(it)) trashRevision++
                else Toast.makeText(context, "복구하지 못했습니다.", Toast.LENGTH_SHORT).show()
            },
            onPermanentDelete = {
                if (onPermanentDeleteTrash(it)) trashRevision++
            }
        )
        return
    }

    Scaffold(
        topBar = {
            ArmyristTopBar(
                title = "실셈",
                subtitle = "COUNTING / 현장 수량 기록",
                leadingLabel = "홈",
                leadingIcon = ArmyristTopBarLeadingIcon.HOME,
                onLeading = onHome
            )
        },
        bottomBar = {
            if (sheets.isNotEmpty()) {
                Surface(color = ArmyristColors.AppBackground) {
                    Button(
                        onClick = onCreate,
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp).heightIn(min = 54.dp),
                        shape = ArmyristControlShape,
                        colors = ButtonDefaults.buttonColors(containerColor = ArmyristColors.PrimaryControl, contentColor = ArmyristColors.OnDark)
                    ) { Text("+  새 실셈 만들기", fontWeight = FontWeight.Bold) }
                }
            }
        }
    ) { padding ->
        if (sheets.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = ArmyristPanelShape,
                    colors = CardDefaults.cardColors(
                        containerColor = ArmyristColors.WorkSurface
                    ),
                    border = BorderStroke(
                        1.dp,
                        ArmyristColors.Border
                    )
                ) {
                    Column(
                        Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("아직 실셈표가 없습니다", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "새 실셈표를 만들어 바로 수량을 기록하세요.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = onCreate,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 54.dp),
                            shape = ArmyristPanelShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ArmyristColors.PrimaryControl,
                                contentColor = ArmyristColors.OnDark
                            )
                        ) {
                            Text(
                                "새 실셈 만들기",
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = openImport,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            shape = ArmyristPanelShape
                        ) {
                        Icon(Icons.Outlined.FileDownload, contentDescription = null, tint = ArmyristColors.PrimaryControl)
                        Spacer(Modifier.width(8.dp))
                        Text("데이터 불러오기")
                    }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(
                    start = 12.dp,
                    end = 12.dp,
                    top = 8.dp,
                    bottom = 96.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "counting-import-trash") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = openImport,
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            shape = ArmyristPanelShape,
                            border = BorderStroke(1.dp, ArmyristColors.Border),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = ArmyristColors.RaisedSurface,
                                contentColor = ArmyristColors.PrimaryText
                            )
                        ) {
                            Icon(Icons.Outlined.FileDownload, contentDescription = null, tint = ArmyristColors.PrimaryControl)
                            Spacer(Modifier.width(8.dp))
                            Text("데이터 불러오기")
                        }
                        OutlinedButton(
                            onClick = { trashOpen = true },
                            modifier = Modifier.heightIn(min = 48.dp),
                            shape = ArmyristPanelShape,
                            border = BorderStroke(1.dp, ArmyristColors.Border),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = ArmyristColors.RaisedSurface,
                                contentColor = ArmyristColors.PrimaryText
                            )
                        ) {
                            Icon(Icons.Outlined.RestoreFromTrash, contentDescription = null, tint = ArmyristColors.PrimaryControl)
                            Spacer(Modifier.width(6.dp))
                            val count = trashRepo.getItems(TrashToolType.COUNTING).size
                            Text(if (count > 0) "휴지통 $count" else "휴지통")
                        }
                    }
                }
                items(sheets, key = { it.id }) { sheet ->
                    Card(
                        onClick = { onOpen(sheet.id) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = ArmyristPanelShape,
                        colors = CardDefaults.cardColors(
                            containerColor = ArmyristColors.RaisedSurface
                        ),
                        border = BorderStroke(
                            1.dp,
                            ArmyristColors.SoftBorder
                        )
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    sheet.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    "항목 ${sheet.items.size} · 그룹 ${sheet.groups.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { renameTarget = sheet }) {
                                Icon(Icons.Outlined.Edit, contentDescription = "이름 변경", tint = ArmyristColors.PrimaryControl)
                            }
                            VerticalDivider(modifier = Modifier.height(30.dp), color = ArmyristColors.SoftBorder)
                            IconButton(onClick = { deleteTarget = sheet }) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "삭제", tint = ArmyristColors.Danger)
                            }
                        }
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        TextInputDialog(
            title = "실셈표 이름 변경",
            initial = target.title,
            helper = "이름을 입력하세요."
        ) {
            renameTarget = null
            if (it != null) onRename(target.id, it)
        }
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "실셈표 삭제",
            message = "'${target.title}'와 모든 항목/그룹/계산을 삭제합니다."
        ) {
            deleteTarget = null
            if (it && !onDeleteToTrash(target.id)) {
                Toast.makeText(context, "휴지통으로 이동하지 못했습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CountingScreen(
    sheet: CountingSheet,
    onHome: () -> Unit,
    onBack: () -> Unit,
    onAddGroup: (String, String, Boolean) -> Unit,
    onRenameGroup: (String, String, String, Boolean) -> Unit,
    onDeleteGroup: (String) -> Unit,
    onCalculations: () -> Unit,
    onResult: () -> Unit,
    onRename: (String) -> Unit,
    onMemo: (String) -> Unit,
    onAddItem: (String, Int, String, String, String?) -> Unit,
    onEditItem: (String, String, String, String, String?) -> Unit,
    onDeleteItem: (String) -> Unit,
    onIncrement: (String) -> Unit,
    onDecrement: (String) -> Unit,
    onQuantity: (String, Int) -> Unit,
    onMove: (String, Int) -> Unit,
    onReorder: (List<String>) -> Boolean,
    onAssignGroup: (Set<String>, String?) -> Unit
) {
    val context = LocalContext.current
    var itemEditor by remember { mutableStateOf<CountingItem?>(null) }
    var creating by rememberSaveable { mutableStateOf(false) }
    var quantityTarget by remember { mutableStateOf<CountingItem?>(null) }
    var deleteTarget by remember { mutableStateOf<CountingItem?>(null) }
    var titleEdit by rememberSaveable { mutableStateOf(false) }
    var memoEdit by rememberSaveable { mutableStateOf(false) }
    var groupManager by rememberSaveable { mutableStateOf(false) }
    var menuTarget by remember { mutableStateOf<CountingItem?>(null) }
    var voiceDrafts by remember { mutableStateOf<List<CountingVoiceDraft>?>(null) }
    var voiceMessage by remember { mutableStateOf<String?>(null) }
    val viewPrefs = remember { context.getSharedPreferences("armyrist_ui", Context.MODE_PRIVATE) }
    var viewMode by remember {
        mutableStateOf(
            if (viewPrefs.getString("counting_view_mode", "DETAILED") == "COMPACT")
                CountingViewMode.COMPACT else CountingViewMode.DETAILED
        )
    }
    var headerMenuOpen by remember { mutableStateOf(false) }
    var viewMenuOpen by remember { mutableStateOf(false) }

    var groupPickerOpen by rememberSaveable { mutableStateOf(false) }
    var assignmentGroupId by rememberSaveable { mutableStateOf<String?>(null) }
    var assignmentSelectedList by rememberSaveable { mutableStateOf(emptyList<String>()) }
    val assignmentSelected = assignmentSelectedList.toSet()

    val listState = rememberLazyListState()
    val compactGridState = rememberLazyGridState()

    val countingReorder = remember(sheet.id) {
        CountingReorderV2(sheet.items)
    }
    val visualItems = countingReorder.items
    val groupsById = remember(sheet.groups) { sheet.groups.associateBy { it.id } }
    val groupMarkers = remember(sheet.groups) {
        sheet.groups.sortedBy { it.order }.groupBy { it.color.lowercase() }.values
            .filter { it.size > 1 }.flatMap { group -> group.mapIndexed { i, value -> value.id to i + 1 } }.toMap()
    }
    val countingDensity = LocalDensity.current

    // -----------------------------------------------------------------
    // Counting Drag Host
    //
    // Gesture ownership lives here at the stable parent layer instead of
    // inside a Lazy item. A dragged item may move off-screen or change slot
    // without destroying the pointer-input node that owns the gesture.
    // -----------------------------------------------------------------
    var dragOverlayItemId by remember(sheet.id) {
        mutableStateOf<String?>(null)
    }
    var dragOverlayCompact by remember(sheet.id) {
        mutableStateOf(false)
    }
    var dragOverlayX by remember(sheet.id) { mutableFloatStateOf(0f) }
    var dragOverlayY by remember(sheet.id) { mutableFloatStateOf(0f) }
    var dragOverlayWidth by remember(sheet.id) { mutableFloatStateOf(0f) }
    var dragOverlayHeight by remember(sheet.id) { mutableFloatStateOf(0f) }

    // The held visual lives outside LazyColumn. Reordering or scroll anchoring
    // can move the placeholder, but cannot change the original grab point.
    var detailedDragDirection by remember(sheet.id) { mutableIntStateOf(0) }

    var dragPointerX by remember(sheet.id) { mutableFloatStateOf(Float.NaN) }
    var dragPointerY by remember(sheet.id) { mutableFloatStateOf(Float.NaN) }
    var dragGrabOffsetX by remember(sheet.id) { mutableFloatStateOf(0f) }
    var dragGrabOffsetY by remember(sheet.id) { mutableFloatStateOf(0f) }

    fun clearCountingOverlay() {
        dragOverlayItemId = null
        dragOverlayX = 0f
        dragOverlayY = 0f
        dragOverlayWidth = 0f
        dragOverlayHeight = 0f
        dragPointerX = Float.NaN
        dragPointerY = Float.NaN
        dragGrabOffsetX = 0f
        dragGrabOffsetY = 0f
        detailedDragDirection = 0
    }

    fun overlayCenterX(): Float =
        dragOverlayX + dragOverlayWidth / 2f

    fun overlayCenterY(): Float =
        dragOverlayY + dragOverlayHeight / 2f

    LaunchedEffect(sheet.updatedAt, sheet.items.size, countingReorder.isDragging) {
        countingReorder.sync(sheet.items)
    }

    fun detailedReorderAtPointer(itemId: String, direction: Int = detailedDragDirection) {
        if (countingReorder.draggingItemId != itemId) return
        val fromIndex = countingReorder.projectedIndexOf(itemId)
        if (fromIndex < 0) return
        val layout = listState.layoutInfo
        val heldInfo = layout.visibleItemsInfo.firstOrNull { it.key == itemId }
        if (heldInfo != null && heldInfo.index != fromIndex) return
        // A projection change must be acknowledged by layout before another
        // swap. Never compare the new order with positions from the old order.
        val slots = layout.visibleItemsInfo.mapNotNull { info ->
            val id = info.key as? String ?: return@mapNotNull null
            val index = countingReorder.projectedIndexOf(id)
            if (index < 0 || info.index != index) return@mapNotNull null
            CountingReorderSlot(
                id, index, 0f,
                CountingDragGeometry.hostY(info.offset, layout.beforeContentPadding) + info.size / 2f,
                0f, info.size.toFloat()
            )
        }
        val targetIndex = CountingDragGeometry.adjacentTarget(
            fromIndex, overlayCenterY(), dragOverlayHeight, direction, slots
        ) ?: return

        // LazyColumn normally follows its first visible key when order changes.
        // If that key is the dragged first row, following it scrolls the list
        // unexpectedly. Keep the viewport's numerical position for this layout.
        val firstIndex = listState.firstVisibleItemIndex
        val firstOffset = listState.firstVisibleItemScrollOffset
        if (countingReorder.movePlaceholderTo(targetIndex)) {
            listState.requestScrollToItem(firstIndex, firstOffset)
        }
    }

    fun compactReorderAtPointer(itemId: String, pointerX: Float, pointerY: Float) {
        if (countingReorder.draggingItemId != itemId) return
        val visible = compactGridState.layoutInfo.visibleItemsInfo
        val held = visible.firstOrNull { it.key == itemId } ?: return
        if (held.index != countingReorder.projectedIndexOf(itemId)) return
        val slots = visible.mapNotNull { info ->
            val id = info.key as? String ?: return@mapNotNull null
            val index = countingReorder.projectedIndexOf(id)
            if (index < 0) return@mapNotNull null
            CountingReorderSlot(
                itemId = id,
                index = index,
                centerX = info.offset.x + info.size.width / 2f,
                centerY = CountingDragGeometry.hostY(info.offset.y, compactGridState.layoutInfo.beforeContentPadding) + info.size.height / 2f,
                width = info.size.width.toFloat(),
                height = info.size.height.toFloat()
            )
        }
        countingReorder.updateCompact(
            pointerX,
            pointerY,
            slots,
            android.os.SystemClock.uptimeMillis()
        )
    }

    fun finishCountingReorder(commit: Boolean) {
        if (commit) {
            val order = countingReorder.commitOrder()
            val previous = sheet.items.sortedBy { it.order }.map { it.id }
            if (order != previous && !onReorder(order)) {
                countingReorder.cancel(sheet.items)
                android.widget.Toast.makeText(context, "순서를 저장하지 못했습니다. 다시 시도해주세요.", android.widget.Toast.LENGTH_LONG).show()
            }
        } else countingReorder.cancel(sheet.items)
    }

    fun findCountingDragTarget(start: Offset): String? {
        val handleWidthPx = with(countingDensity) { 60.dp.toPx() }

        return if (viewMode == CountingViewMode.COMPACT) {
            compactGridState.layoutInfo.visibleItemsInfo
                .firstOrNull { info ->
                    val left = info.offset.x.toFloat()
                    val top = CountingDragGeometry.hostY(info.offset.y, compactGridState.layoutInfo.beforeContentPadding)
                    val right = left + info.size.width
                    val bottom = top + info.size.height

                    start.x >= left &&
                        start.x <= minOf(
                            right,
                            left + handleWidthPx
                        ) &&
                        start.y >= top &&
                        start.y <= bottom
                }
                ?.key as? String
        } else {
            listState.layoutInfo.visibleItemsInfo
                .firstOrNull { info ->
                    val key = info.key as? String
                        ?: return@firstOrNull false
                    if (countingReorder.projectedIndexOf(key) < 0) {
                        return@firstOrNull false
                    }

                    val left = 0f
                    val top = CountingDragGeometry.hostY(info.offset, listState.layoutInfo.beforeContentPadding)
                    val right = handleWidthPx
                    val bottom = top + info.size

                    start.x >= left &&
                        start.x <= right &&
                        start.y >= top &&
                        start.y <= bottom
                }
                ?.key as? String
        }
    }

    fun beginCountingDrag(
        itemId: String,
        start: Offset
    ) {
        val compact = viewMode == CountingViewMode.COMPACT

        if (compact) {
            val info = compactGridState.layoutInfo.visibleItemsInfo
                .firstOrNull { it.key == itemId }
                ?: return

            countingReorder.begin(
                itemId,
                CountingReorderMode.COMPACT
            )
            dragOverlayItemId = itemId
            dragOverlayCompact = true
            dragOverlayX = info.offset.x.toFloat()
            dragOverlayY = CountingDragGeometry.hostY(info.offset.y, compactGridState.layoutInfo.beforeContentPadding)
            dragOverlayWidth = info.size.width.toFloat()
            dragOverlayHeight = info.size.height.toFloat()
        } else {
            val info = listState.layoutInfo.visibleItemsInfo
                .firstOrNull { it.key == itemId }
                ?: return

            countingReorder.begin(
                itemId,
                CountingReorderMode.DETAILED
            )
            dragOverlayItemId = itemId
            dragOverlayCompact = false
            detailedDragDirection = 0
            val horizontalPadding = with(countingDensity) { 8.dp.toPx() }
            dragOverlayX = horizontalPadding
            dragOverlayY = CountingDragGeometry.hostY(info.offset, listState.layoutInfo.beforeContentPadding)
            dragOverlayWidth = listState.layoutInfo.viewportSize.width - horizontalPadding * 2f
            dragOverlayHeight = info.size.toFloat()
        }

        dragPointerX = start.x
        dragPointerY = start.y
        dragGrabOffsetX = start.x - dragOverlayX
        dragGrabOffsetY = start.y - dragOverlayY
    }

    fun updateCountingDrag(position: Offset, delta: Offset) {
        val itemId = dragOverlayItemId ?: return
        if (dragPointerX.isNaN() || dragPointerY.isNaN()) return
        dragPointerX = position.x
        dragPointerY = position.y
        // Absolute host coordinates are the sole visual source of truth.
        // Do not clamp, accumulate swap corrections, or add consumed scroll.
        dragOverlayY = CountingDragGeometry.overlayTop(dragPointerY, dragGrabOffsetY)
        if (dragOverlayCompact) {
            dragOverlayX = dragPointerX - dragGrabOffsetX
            compactReorderAtPointer(itemId, overlayCenterX(), overlayCenterY())
        } else {
            if (delta.y != 0f) detailedDragDirection = if (delta.y > 0f) 1 else -1
            detailedReorderAtPointer(itemId)
        }
    }

    fun finishParentCountingDrag(commit: Boolean) {
        if (dragOverlayItemId == null) return
        finishCountingReorder(commit)
        clearCountingOverlay()
    }

    // A proportional edge band leaves a neutral centre even when the summary
    // above the list leaves only a few rows of usable viewport height.
    LaunchedEffect(dragOverlayItemId, dragOverlayCompact) {
        val requestedEdgePx = with(countingDensity) { 112.dp.toPx() }
        val maxStepPx = with(countingDensity) { 12.dp.toPx() }
        var previousFrame = 0L
        while (dragOverlayItemId != null) {
            val frame = withFrameNanos { it }
            val scale = DragMotion.frameScale(previousFrame, frame)
            previousFrame = frame
            val itemId = dragOverlayItemId ?: break
            val height = if (dragOverlayCompact) {
                compactGridState.layoutInfo.viewportSize.height
            } else listState.layoutInfo.viewportSize.height
            val fraction = CountingDragGeometry.edgeScrollFraction(
                dragPointerY, height.toFloat(), requestedEdgePx
            )
            val consumed = if (fraction == 0f) 0f else if (dragOverlayCompact) {
                compactGridState.scrollBy(maxStepPx * fraction * scale)
            } else {
                listState.scrollBy(maxStepPx * fraction * scale)
            }
            if (dragOverlayCompact) {
                compactReorderAtPointer(itemId, overlayCenterX(), overlayCenterY())
            } else {
                val direction = if (consumed > 0f) 1 else if (consumed < 0f) -1 else detailedDragDirection
                detailedReorderAtPointer(itemId, direction)
            }
        }
    }

    BackHandler {
        if (assignmentGroupId != null) {
            assignmentGroupId = null
            assignmentSelectedList = emptyList()
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            ArmyristTopBar(
                title = sheet.title,
                subtitle = "COUNTING · 항목 ${sheet.items.size} · AUTO SAVE",
                leadingLabel = "홈",
                leadingIcon = ArmyristTopBarLeadingIcon.HOME,
                onLeading = onHome,
                secondaryLeadingLabel = "메뉴",
                onSecondaryLeading = onBack,
                onTitleClick = { titleEdit = true },
                actions = {
                    Box {
                        TextButton(onClick = { viewMenuOpen = true }) {
                            Text("☷", color = ArmyristColors.OnDark, style = MaterialTheme.typography.titleLarge)
                        }
                        DropdownMenu(expanded = viewMenuOpen, onDismissRequest = { viewMenuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(if (viewMode == CountingViewMode.DETAILED) "● 상세 보기 (기본)" else "○ 상세 보기 (기본)") },
                                onClick = {
                                    viewMode = CountingViewMode.DETAILED
                                    viewPrefs.edit().putString("counting_view_mode", "DETAILED").apply()
                                    viewMenuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (viewMode == CountingViewMode.COMPACT) "● 컴팩트 보기" else "○ 컴팩트 보기") },
                                onClick = {
                                    viewMode = CountingViewMode.COMPACT
                                    viewPrefs.edit().putString("counting_view_mode", "COMPACT").apply()
                                    viewMenuOpen = false
                                }
                            )
                        }
                    }
                    Box {
                        TextButton(onClick = { headerMenuOpen = true }) { Text("⋮", color = ArmyristColors.OnDark, style = MaterialTheme.typography.titleLarge) }
                        DropdownMenu(expanded = headerMenuOpen, onDismissRequest = { headerMenuOpen = false }) {
                            DropdownMenuItem(text = { Text("결과 전달") }, onClick = { headerMenuOpen = false; onResult() })
                            DropdownMenuItem(text = { Text("계산") }, onClick = { headerMenuOpen = false; onCalculations() })
                            DropdownMenuItem(text = { Text("메모") }, onClick = { headerMenuOpen = false; memoEdit = true })
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ArmyristUtilityActionButton("그룹 설정", { groupManager = true }, Modifier.weight(1f))
                ArmyristUtilityActionButton("그룹 지정", { groupPickerOpen = true }, Modifier.weight(1f))
                Box(Modifier.weight(1f)) {
                    OfflineVoiceButton(
                        toolContext = VoiceToolContext.COUNTING,
                        modifier = Modifier.fillMaxWidth(),
                        onTranscript = { transcript -> voiceDrafts = KoreanVoiceStructurer.counting(transcript) },
                        onMessage = { voiceMessage = it }
                    )
                }
            }

            AggregateSummary(sheet)
            CalculationSummary(sheet)

            if (assignmentGroupId != null) {
                val targetGroup = sheet.groups.firstOrNull { it.id == assignmentGroupId }
                val targetLabel =
                    if (assignmentGroupId?.isEmpty() == true) {
                        "미지정"
                    } else {
                        targetGroup?.name ?: "그룹"
                    }

                Surface(
                    color = targetGroup?.let { parseColor(it.color).copy(alpha = 0.14f) }
                        ?: ArmyristColors.SecondaryControl,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "$targetLabel 지정 중",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "항목을 터치해 선택 · ${assignmentSelected.size}개",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        TextButton(
                            onClick = {
                                assignmentGroupId = null
                                assignmentSelectedList = emptyList()
                            }
                        ) {
                            Text("취소")
                        }
                        Button(
                            enabled = assignmentSelected.isNotEmpty(),
                            onClick = {
                                onAssignGroup(
                                    assignmentSelected,
                                    assignmentGroupId?.takeIf { it.isNotEmpty() }
                                )
                                assignmentGroupId = null
                                assignmentSelectedList = emptyList()
                            }
                        ) {
                            Text("확인")
                        }
                    }
                }
            }

            HorizontalDivider()

            // Density mode is a layout switch, not a screen transition. Keeping both
            // lazy layouts alive during Crossfade caused stale placement frames and
            // visible flashing after drag/reorder. Render exactly one layout.
            val animatedViewMode = viewMode
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clipToBounds()
                    .pointerInput(
                        sheet.id,
                        viewMode,
                        visualItems.size
                    ) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { start ->
                                findCountingDragTarget(start)
                                    ?.let { targetId ->
                                        beginCountingDrag(
                                            targetId,
                                            start
                                        )
                                    }
                            },
                            onDragCancel = {
                                finishParentCountingDrag(
                                    commit = false
                                )
                            },
                            onDragEnd = {
                                finishParentCountingDrag(
                                    commit = true
                                )
                            },
                            onDrag = { change, dragAmount ->
                                if (dragOverlayItemId != null) {
                                    change.consume()
                                    updateCountingDrag(change.position, dragAmount)
                                }
                            }
                        )
                    }
            ) {
            val detailedCardNarrow = maxWidth - 16.dp < 430.dp
            val detailedCard: @Composable (CountingItem, Int, Modifier, Boolean) -> Unit =
                { item, index, cardModifier, detailedDragging ->
                    val currentGroup = groupsById[item.groupId]
                    val groupName = currentGroup?.name ?: "미지정"
                    val assignmentMode = assignmentGroupId != null
                    val selected = item.id in assignmentSelected

                    val groupColor =
                        currentGroup?.let { parseColor(it.color) }

                    val baseColor = groupColor
                        ?.copy(alpha = 0.13f)
                        ?: ArmyristColors.RaisedSurface

                    val selectedColor = sheet.groups
                        .firstOrNull { it.id == assignmentGroupId }
                        ?.let { parseColor(it.color).copy(alpha = 0.26f) }
                        ?: ArmyristColors.SecondaryControl

                    val detailedDragHandleModifier = Modifier


                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor =
                                if (selected) {
                                    selectedColor
                                } else {
                                    baseColor
                                }
                        ),
                        shape = ArmyristPanelShape,
                        border = BorderStroke(
                            1.dp,
                            when {
                                selected -> ArmyristColors.PrimaryControl
                                groupColor != null ->
                                    groupColor.copy(alpha = 0.75f)
                                else -> ArmyristColors.Divider
                            }
                        ),
                        modifier = cardModifier
                            .clickable {
                                if (assignmentMode) {
                                    assignmentSelectedList =
                                        (if (selected) assignmentSelected - item.id
                                        else assignmentSelected + item.id).toList()
                                } else {
                                    itemEditor = item
                                }
                            }
                    ) {
                        Box(Modifier.fillMaxWidth()) {
                            val stackedDetailed =
                                animatedViewMode == CountingViewMode.DETAILED && detailedCardNarrow

                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                            if (groupColor != null) {
                                Box(
                                    Modifier
                                        .width(5.dp)
                                        .heightIn(min = if (animatedViewMode == CountingViewMode.COMPACT) 44.dp else 88.dp)
                                        .background(groupColor)
                                )
                            }

                            if (stackedDetailed) {
                                Column(
                                    Modifier
                                        .weight(1f)
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Box(
                                            modifier = detailedDragHandleModifier
                                                .size(40.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "⠿",
                                                color =
                                                    if (detailedDragging) {
                                                        ArmyristColors.PrimaryControl
                                                    } else {
                                                        ArmyristColors.SecondaryText
                                                    },
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Text(
                                            if (selected) "✓" else "${index + 1}.",
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.width(34.dp)
                                        )
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                item.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                "${item.unit} · $groupName",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (item.note.isNotBlank()) {
                                                Text(
                                                    "비고: ${item.note}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        if (!assignmentMode) {
                                            TextButton(
                                                onClick = { menuTarget = item },
                                                modifier = Modifier.widthIn(min = 48.dp).heightIn(min = 48.dp)
                                            ) { Text("⋮") }
                                        }
                                    }

                                    if (!assignmentMode) {
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            OutlinedButton(
                                                onClick = { onDecrement(item.id) },
                                                modifier = Modifier.sizeIn(minWidth = 56.dp, minHeight = 56.dp),
                                                shape = ArmyristPanelShape,
                                                border = BorderStroke(1.dp, ArmyristColors.Border),
                                                contentPadding = PaddingValues(0.dp)
                                            ) { Text("−", style = MaterialTheme.typography.titleLarge) }
                                            Spacer(Modifier.width(12.dp))
                                            Button(
                                                onClick = { quantityTarget = item },
                                                modifier = Modifier.widthIn(min = 78.dp).heightIn(min = 58.dp),
                                                shape = ArmyristPanelShape,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = ArmyristColors.HeaderRaised,
                                                    contentColor = ArmyristColors.OnDark
                                                ),
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) {
                                                Text(
                                                    item.quantity.toString(),
                                                    style = MaterialTheme.typography.headlineMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Button(
                                                onClick = { onIncrement(item.id) },
                                                modifier = Modifier.sizeIn(minWidth = 56.dp, minHeight = 56.dp),
                                                shape = ArmyristPanelShape,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = ArmyristColors.PrimaryControl,
                                                    contentColor = ArmyristColors.OnDark
                                                ),
                                                contentPadding = PaddingValues(0.dp)
                                            ) { Text("+", style = MaterialTheme.typography.titleLarge) }
                                        }
                                    }
                                }
                            } else {
                            Row(
                                Modifier
                                    .weight(1f)
                                    .padding(
                                        horizontal = if (animatedViewMode == CountingViewMode.COMPACT) 8.dp else 12.dp,
                                        vertical = if (animatedViewMode == CountingViewMode.COMPACT) 2.dp else 14.dp
                                    ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                            if (!assignmentMode) {
                                Box(
                                    modifier = detailedDragHandleModifier
                                        .size(40.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "⠿",
                                        color =
                                            if (detailedDragging) {
                                                ArmyristColors.PrimaryControl
                                            } else {
                                                ArmyristColors.SecondaryText
                                            },
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                if (selected) "✓" else "${index + 1}.",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(34.dp)
                            )

                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.name,
                                    style = if (animatedViewMode == CountingViewMode.COMPACT) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    if (animatedViewMode == CountingViewMode.COMPACT) "${item.unit}  $groupName" else "${item.unit} · $groupName",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (animatedViewMode == CountingViewMode.DETAILED && item.note.isNotBlank()) {
                                    Text(
                                        "비고: ${item.note}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (!assignmentMode) {
                                OutlinedButton(
                                    onClick = { onDecrement(item.id) },
                                    modifier = Modifier.sizeIn(
                                        minWidth = if (animatedViewMode == CountingViewMode.COMPACT) 40.dp else 56.dp,
                                        minHeight = if (animatedViewMode == CountingViewMode.COMPACT) 40.dp else 56.dp
                                    ),
                                    shape = ArmyristPanelShape,
                                    border = BorderStroke(
                                        1.dp,
                                        ArmyristColors.Border
                                    ),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("−", style = MaterialTheme.typography.titleLarge)
                                }

                                Button(
                                    onClick = { quantityTarget = item },
                                    modifier = Modifier
                                        .widthIn(min = if (animatedViewMode == CountingViewMode.COMPACT) 46.dp else 78.dp)
                                        .heightIn(min = if (animatedViewMode == CountingViewMode.COMPACT) 40.dp else 58.dp),
                                    shape = ArmyristPanelShape,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor =
                                            ArmyristColors.HeaderRaised,
                                        contentColor =
                                            ArmyristColors.OnDark
                                    ),
                                    contentPadding = PaddingValues(
                                        horizontal = 8.dp
                                    )
                                ) {
                                    Text(
                                        item.quantity.toString(),
                                        style =
                                            if (animatedViewMode == CountingViewMode.COMPACT) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = { onIncrement(item.id) },
                                    modifier = Modifier.sizeIn(
                                        minWidth = if (animatedViewMode == CountingViewMode.COMPACT) 40.dp else 56.dp,
                                        minHeight = if (animatedViewMode == CountingViewMode.COMPACT) 40.dp else 56.dp
                                    ),
                                    shape = ArmyristPanelShape,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor =
                                            ArmyristColors.PrimaryControl,
                                        contentColor =
                                            ArmyristColors.OnDark
                                    ),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("+", style = MaterialTheme.typography.titleLarge)
                                }

                                Box {
                                    TextButton(
                                        onClick = { menuTarget = item },
                                        modifier = Modifier.widthIn(min = 44.dp)
                                    ) {
                                        Text("⋮")
                                    }

                                    DropdownMenu(
                                        expanded = menuTarget?.id == item.id,
                                        onDismissRequest = { menuTarget = null }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("편집") },
                                            onClick = {
                                                menuTarget = null
                                                itemEditor = item
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("위로 이동") },
                                            onClick = {
                                                menuTarget = null
                                                onMove(item.id, -1)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("아래로 이동") },
                                            onClick = {
                                                menuTarget = null
                                                onMove(item.id, 1)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("삭제") },
                                            onClick = {
                                                menuTarget = null
                                                deleteTarget = item
                                            }
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    item.quantity.toString(),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                            }
                            } // responsive horizontal branch
                        } // Card content
                    }
                }
                }
            if (animatedViewMode == CountingViewMode.COMPACT) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    state = compactGridState,
                    userScrollEnabled = dragOverlayItemId == null,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (sheet.items.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("항목이 없습니다", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                Text("아래 새 항목 추가 버튼으로 시작하세요.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    gridItems(
                        items = visualItems,
                        key = { it.id },
                        contentType = { "counting-grid-item" }
                    ) { item ->
                        val displayIndex = countingReorder.projectedIndexOf(item.id) + 1
                        val currentGroup = groupsById[item.groupId]
                        val groupColor = currentGroup?.let { parseColor(it.color) }
                        val assignmentMode = assignmentGroupId != null
                        val selected = item.id in assignmentSelected
                        val selectedColor = sheet.groups
                            .firstOrNull { it.id == assignmentGroupId }
                            ?.let { parseColor(it.color).copy(alpha = 0.26f) }
                            ?: ArmyristColors.SecondaryControl

                        val compactDragging = dragOverlayCompact && dragOverlayItemId == item.id

                        // Group marker number is presentation-only.
                        // It appears only when multiple groups use the same configured color.
                        val markerNumber = currentGroup?.let { groupMarkers[it.id] }

                        val compactBackground = when {
                            selected -> selectedColor
                            groupColor != null -> groupColor.copy(alpha = 0.12f)
                            else -> ArmyristColors.RaisedSurface
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = compactBackground),
                            shape = ArmyristPanelShape,
                            border = BorderStroke(
                                1.dp,
                                when {
                                    selected -> ArmyristColors.PrimaryControl
                                    groupColor != null -> groupColor.copy(alpha = 0.62f)
                                    else -> ArmyristColors.Divider
                                }
                            ),
                            modifier = (
                                if (compactDragging) {
                                    Modifier.fillMaxWidth()
                                } else {
                                    Modifier
                                        .fillMaxWidth()
                                        .animateItem(
                                            fadeInSpec = null,
                                            placementSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioNoBouncy),
                                            fadeOutSpec = null
                                        )
                                }
                            )
                                .heightIn(min = 96.dp)
                                .zIndex(0f)
                                .graphicsLayer {
                                    // Keep this cell's exact layout size as the
                                    // placeholder, but render its content only
                                    // through the detached overlay.
                                    alpha =
                                        if (dragOverlayItemId == item.id) {
                                            0f
                                        } else {
                                            1f
                                        }
                                    translationX = 0f
                                    translationY = 0f
                                    shadowElevation = 0f
                                    scaleX = 1f
                                    scaleY = 1f
                                }
                                .clickable {
                                    if (assignmentMode) {
                                        assignmentSelectedList =
                                            (if (selected) assignmentSelected - item.id
                                            else assignmentSelected + item.id).toList()
                                    } else {
                                        itemEditor = item
                                    }
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!assignmentMode) {
                                        Box(
                                            modifier = Modifier
                                                .sizeIn(
                                                    minWidth = 40.dp,
                                                    minHeight = 40.dp
                                                )
,
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "⠿",
                                                style = MaterialTheme.typography.titleMedium,
                                                color = ArmyristColors.SecondaryText,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(Modifier.width(2.dp))
                                    }

                                    Text(
                                        "$displayIndex.",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        item.name,
                                        modifier = Modifier.weight(1f),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )

                                    if (groupColor != null) {
                                        Surface(
                                            color = groupColor,
                                            contentColor = ArmyristColors.OnDark,
                                            shape = ArmyristPanelShape,
                                            border = BorderStroke(
                                                1.dp,
                                                groupColor.copy(alpha = 0.90f)
                                            ),
                                            modifier = Modifier.sizeIn(
                                                minWidth = 22.dp,
                                                minHeight = 20.dp
                                            )
                                        ) {
                                            Box(
                                                modifier = Modifier.padding(
                                                    horizontal = if (markerNumber != null) 5.dp else 7.dp,
                                                    vertical = 2.dp
                                                ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (markerNumber != null) {
                                                    Text(
                                                        markerNumber.toString(),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                if (assignmentMode) {
                                    Text(
                                        if (selected) "✓ 선택됨" else "선택",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) {
                                            ArmyristColors.PrimaryControl
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    )
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        OutlinedButton(
                                            onClick = { onDecrement(item.id) },
                                            modifier = Modifier.sizeIn(
                                                minWidth = 48.dp,
                                                minHeight = 48.dp
                                            ),
                                            shape = ArmyristPanelShape,
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text(
                                                "−",
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        TextButton(
                                            onClick = { quantityTarget = item },
                                            modifier = Modifier
                                                .widthIn(min = 44.dp)
                                                .heightIn(min = 48.dp),
                                            contentPadding = PaddingValues(horizontal = 4.dp)
                                        ) {
                                            Text(
                                                item.quantity.toString(),
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleLarge
                                            )
                                        }

                                        Button(
                                            onClick = { onIncrement(item.id) },
                                            modifier = Modifier.sizeIn(
                                                minWidth = 48.dp,
                                                minHeight = 48.dp
                                            ),
                                            shape = ArmyristPanelShape,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = ArmyristColors.PrimaryControl,
                                                contentColor = ArmyristColors.OnDark
                                            ),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text(
                                                "+",
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item(span = { GridItemSpan(maxLineSpan) }) {
                        OutlinedButton(
                            onClick = { creating = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                            shape = ArmyristPanelShape,
                            border = BorderStroke(1.dp, ArmyristColors.Accent)
                        ) { Text("+ 새 항목 추가") }
                    }
                }
            } else {
            LazyColumn(
                state = listState,
                userScrollEnabled = dragOverlayItemId == null,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 8.dp,
                    end = 8.dp,
                    top = 6.dp,
                    bottom = 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(if (animatedViewMode == CountingViewMode.COMPACT) 2.dp else 6.dp)
            ) {
                if (sheet.items.isEmpty()) {
                    item {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("항목이 없습니다", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "아래 새 항목 추가 버튼으로 시작하세요.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                itemsIndexed(
                    visualItems,
                    key = { _, item -> item.id },
                    contentType = { _, _ -> "counting-item" }
                ) { index, item ->
                    val dragging = !dragOverlayCompact && dragOverlayItemId == item.id
                    val placement = if (dragging) Modifier else Modifier.animateItem(
                        fadeInSpec = null,
                        placementSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioNoBouncy),
                        fadeOutSpec = null
                    )
                    detailedCard(item, index, placement.fillMaxWidth().graphicsLayer {
                        alpha = if (dragging) 0f else 1f
                    }, false)
            } // itemsIndexed

                item {
                    OutlinedButton(
                        onClick = { creating = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 54.dp),
                        shape = ArmyristPanelShape,
                        border = BorderStroke(
                            1.dp,
                            ArmyristColors.Accent
                        )
                    ) {
                        Text("+ 새 항목 추가")
                    }
                }

                item {
                    Card(
                        onClick = { memoEdit = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = ArmyristPanelShape,
                        colors = CardDefaults.cardColors(
                            containerColor = ArmyristColors.WorkSurface
                        ),
                        border = BorderStroke(
                            1.dp,
                            ArmyristColors.SoftBorder
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "메모",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    "편집",
                                    color = ArmyristColors.PrimaryControl
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                sheet.memo.ifBlank {
                                    "메모가 없습니다. 눌러서 입력하세요."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (sheet.memo.isBlank()) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                }
                            )
                        }
                    }
                }
            }
            }

            val overlayItem =
                dragOverlayItemId?.let { id ->
                    visualItems.firstOrNull { it.id == id }
                        ?: sheet.items.firstOrNull { it.id == id }
                }

            if (!dragOverlayCompact && overlayItem != null && dragOverlayWidth > 0f) {
                detailedCard(
                    overlayItem, countingReorder.projectedIndexOf(overlayItem.id),
                    Modifier.width(with(countingDensity) { dragOverlayWidth.toDp() })
                        .height(with(countingDensity) { dragOverlayHeight.toDp() })
                        .zIndex(100f)
                        .graphicsLayer {
                            translationX = dragOverlayX
                            translationY = dragOverlayY
                            shadowElevation = 7f
                        },
                    true
                )
            }

            if (
                dragOverlayCompact &&
                overlayItem != null &&
                dragOverlayWidth > 0f &&
                dragOverlayHeight > 0f
            ) {
                val overlayGroup =
                    sheet.groups.firstOrNull {
                        it.id == overlayItem.groupId
                    }
                val overlayGroupColor =
                    overlayGroup?.let { parseColor(it.color) }
                val overlayContainer =
                    overlayGroupColor
                        ?.copy(alpha = 0.16f)
                        ?: ArmyristColors.RaisedSurface
                val overlayWidthDp =
                    with(countingDensity) {
                        dragOverlayWidth.toDp()
                    }
                val overlayHeightDp =
                    with(countingDensity) {
                        dragOverlayHeight.toDp()
                    }

                Card(
                    modifier = Modifier
                        .width(overlayWidthDp)
                        .height(overlayHeightDp)
                        .zIndex(100f)
                        .graphicsLayer {
                            translationX = dragOverlayX
                            translationY = dragOverlayY
                            shadowElevation = 7f
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = overlayContainer
                    ),
                    shape = ArmyristPanelShape,
                    border = BorderStroke(
                        1.5.dp,
                        overlayGroupColor
                            ?.copy(alpha = 0.72f)
                            ?: ArmyristColors.PrimaryControl
                    )
                ) {
                    if (dragOverlayCompact) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 8.dp
                                ),
                            verticalArrangement =
                                Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Text(
                                    "⠿",
                                    color =
                                        ArmyristColors.PrimaryControl,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    overlayItem.name,
                                    modifier = Modifier.weight(1f),
                                    style =
                                        MaterialTheme.typography
                                            .labelLarge,
                                    fontWeight =
                                        FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow =
                                        androidx.compose.ui.text.style
                                            .TextOverflow.Ellipsis
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement =
                                    Arrangement.SpaceBetween,
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Text(
                                    overlayGroup?.name ?: "미지정",
                                    style =
                                        MaterialTheme.typography
                                            .bodySmall,
                                    color =
                                        MaterialTheme.colorScheme
                                            .onSurfaceVariant
                                )
                                Text(
                                    overlayItem.quantity.toString(),
                                    style =
                                        MaterialTheme.typography
                                            .titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color =
                                        ArmyristColors.PrimaryControl
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 14.dp),
                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {
                            Text(
                                "⠿",
                                color = ArmyristColors.PrimaryControl,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    overlayItem.name,
                                    style =
                                        MaterialTheme.typography
                                            .titleMedium,
                                    fontWeight =
                                        FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow =
                                        androidx.compose.ui.text.style
                                            .TextOverflow.Ellipsis
                                )
                                Text(
                                    buildString {
                                        append(
                                            overlayGroup?.name
                                                ?: "미지정"
                                        )
                                        if (
                                            overlayItem.note
                                                .isNotBlank()
                                        ) {
                                            append(" · ")
                                            append(overlayItem.note)
                                        }
                                    },
                                    style =
                                        MaterialTheme.typography
                                            .bodySmall,
                                    color =
                                        MaterialTheme.colorScheme
                                            .onSurfaceVariant,
                                    maxLines = 1,
                                    overflow =
                                        androidx.compose.ui.text.style
                                            .TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                overlayItem.quantity.toString(),
                                style =
                                    MaterialTheme.typography
                                        .headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color =
                                    ArmyristColors.PrimaryControl
                            )
                        }
                    }
                }
            }
            } // detached Counting drag layer
        }
    }

    if (creating) {
        ItemDialog(sheet, null) { data ->
            creating = false
            data?.let {
                onAddItem(it.name, it.quantity, it.unit, it.note, it.groupId)
            }
        }
    }

    itemEditor?.let { item ->
        ItemDialog(sheet, item) { data ->
            itemEditor = null
            data?.let {
                onEditItem(item.id, it.name, it.unit, it.note, it.groupId)
            }
        }
    }

    quantityTarget?.let { item ->
        QuantityDialog(item.quantity) { quantity ->
            quantityTarget = null
            if (quantity != null) onQuantity(item.id, quantity)
        }
    }

    deleteTarget?.let { item ->
        ConfirmDialog(
            title = "항목 삭제",
            message = "'${item.name}' 항목만 삭제합니다."
        ) {
            deleteTarget = null
            if (it) onDeleteItem(item.id)
        }
    }

    if (groupPickerOpen) {
        GroupPickerDialog(sheet) { groupId ->
            groupPickerOpen = false
            if (groupId != null) {
                assignmentGroupId =
                    if (groupId == "__UNASSIGNED__") "" else groupId
                assignmentSelectedList = emptyList()
            }
        }
    }

    if (titleEdit) {
        TextInputDialog(
            title = "제목 변경",
            initial = sheet.title,
            helper = "빈 제목은 저장할 수 없습니다."
        ) {
            titleEdit = false
            if (it != null && it.trim().isNotEmpty()) onRename(it)
        }
    }

    if (groupManager) {
        CountingGroupManagerDialog(
            sheet = sheet,
            onAdd = onAddGroup,
            onRename = onRenameGroup,
            onDelete = onDeleteGroup,
            onDismiss = { groupManager = false }
        )
    }

    if (memoEdit) {
        TextInputDialog(
            title = "실셈표 메모",
            initial = sheet.memo,
            helper = "",
            allowEmpty = true,
            singleLine = false
        ) {
            memoEdit = false
            if (it != null) onMemo(it)
        }
    }

    voiceDrafts?.let { drafts ->
        CountingVoiceReviewDialog(
            initial = drafts,
            onDismiss = { voiceDrafts = null },
            onApply = { applied ->
                applied.forEach { d ->
                    val q = d.quantity ?: return@forEach
                    val u = d.unit?.takeIf { it.isNotBlank() } ?: return@forEach
                    onAddItem(d.name, q, u, d.note, null)
                }
                voiceDrafts = null
            }
        )
    }

    voiceMessage?.let { msg ->
        ArmyristDialog(
            onDismissRequest = { voiceMessage = null },
            title = { Text("음성 입력") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { voiceMessage = null }) { Text("확인") } }
        )
    }
}

@Composable
private fun ArmyristUtilityButton(
    text: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        shape = ArmyristPanelShape,
        border = BorderStroke(
            1.dp,
            ArmyristColors.Border
        ),
        contentPadding =
            PaddingValues(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun AggregateSummary(sheet: CountingSheet) {
    val sections = mutableListOf<Pair<String, Map<String, Int>>>()

    sheet.groups.sortedBy { it.order }.forEach { group ->
        if (!group.showAggregate) return@forEach

        val totals = DomainRules.aggregate(
            sheet.items.filter { it.groupId == group.id }
        )
        if (totals.isNotEmpty()) {
            sections += group.name to totals
        }
    }

    val ungrouped = sheet.items.filter { it.groupId == null }
    if (ungrouped.isNotEmpty()) {
        sections += "미지정" to DomainRules.aggregate(ungrouped)
    }

    if (sections.isNotEmpty()) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                "현재 합계",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )

            LazyColumn(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 112.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(sections) { (name, totals) ->
                    val group = sheet.groups.firstOrNull { it.name == name }
                    Surface(
                        color = group?.let {
                            parseColor(it.color).copy(alpha = 0.12f)
                        } ?: ArmyristColors.RaisedSurface,
                        shape = ArmyristPanelShape,
                        border = BorderStroke(
                            1.dp,
                            ArmyristColors.SoftBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                name,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.widthIn(min = 76.dp)
                            )
                            Text(
                                totals.entries.joinToString("   ") {
                                    "${it.key} ${it.value}"
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalculationSummary(sheet: CountingSheet) {
    if (sheet.calculations.isEmpty()) return

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            "그룹 계산",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        sheet.calculations.forEach { calculation ->
            val leftGroup = sheet.groups.firstOrNull {
                it.id == calculation.leftGroupId
            } ?: return@forEach
            val rightGroup = sheet.groups.firstOrNull {
                it.id == calculation.rightGroupId
            } ?: return@forEach

            val left = DomainRules.aggregate(
                sheet.items.filter { it.groupId == leftGroup.id }
            )
            val right = DomainRules.aggregate(
                sheet.items.filter { it.groupId == rightGroup.id }
            )
            val result = DomainRules.calculate(
                left,
                calculation.operator,
                right
            )

            val symbol = if (calculation.operator == CalculationOperator.ADD) "+" else "−"
            val label = calculation.name.ifBlank {
                "${leftGroup.name} $symbol ${rightGroup.name}"
            }

            Surface(
                tonalElevation = 1.dp,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        label,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.widthIn(min = 110.dp)
                    )
                    Text(
                        result.entries.joinToString("   ") {
                            "${it.key} ${it.value}"
                        }
                    )
                }
            }
        }
    }
}

private data class ItemDraft(
    val name: String,
    val quantity: Int,
    val unit: String,
    val note: String,
    val groupId: String?
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ItemDialog(
    sheet: CountingSheet,
    item: CountingItem?,
    done: (ItemDraft?) -> Unit
) {
    var name by remember { mutableStateOf(item?.name ?: "") }
    var quantityRaw by remember {
        mutableStateOf(item?.quantity?.toString() ?: "0")
    }
    var unit by remember { mutableStateOf(item?.unit ?: "개") }
    var note by remember { mutableStateOf(item?.note ?: "") }
    var groupId by remember { mutableStateOf(item?.groupId) }
    var error by remember { mutableStateOf("") }

    ArmyristDialog(
        onDismissRequest = { done(null) },
        shape = ArmyristPanelShape,
        containerColor = ArmyristColors.WorkSurface,
        title = {
            Column {
                Text(
                    if (item == null) "항목 추가" else "항목 편집",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "COUNTING ITEM",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArmyristColors.SecondaryText
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        error = ""
                    },
                    label = { Text("항목명") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = ArmyristColors.InputSurface,
                        unfocusedContainerColor = ArmyristColors.InputSurface,
                        focusedBorderColor = ArmyristColors.PrimaryControl,
                        unfocusedBorderColor = ArmyristColors.Border
                    )
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (item == null) {
                        OutlinedTextField(
                            value = quantityRaw,
                            onValueChange = {
                                quantityRaw = it
                                error = ""
                            },
                            label = { Text("수량") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number
                            ),
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = ArmyristColors.InputSurface,
                                unfocusedContainerColor = ArmyristColors.InputSurface,
                                focusedBorderColor = ArmyristColors.PrimaryControl,
                                unfocusedBorderColor = ArmyristColors.Border
                            )
                        )
                    }

                    OutlinedTextField(
                        value = unit,
                        onValueChange = {
                            unit = it
                            error = ""
                        },
                        label = { Text("단위") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = ArmyristColors.InputSurface,
                            unfocusedContainerColor = ArmyristColors.InputSurface,
                            focusedBorderColor = ArmyristColors.PrimaryControl,
                            unfocusedBorderColor = ArmyristColors.Border
                        )
                    )
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("비고") },
                    minLines = 1,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = ArmyristColors.InputSurface,
                        unfocusedContainerColor = ArmyristColors.InputSurface,
                        focusedBorderColor = ArmyristColors.PrimaryControl,
                        unfocusedBorderColor = ArmyristColors.Border
                    )
                )

                Text(
                    "그룹",
                    fontWeight = FontWeight.SemiBold
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    maxItemsInEachRow = 3
                ) {
                    val unassignedSelected = groupId == null
                    Surface(
                        onClick = { groupId = null },
                        shape = ArmyristPanelShape,
                        color =
                            if (unassignedSelected) {
                                ArmyristColors.SecondaryControl
                            } else {
                                ArmyristColors.RaisedSurface
                            },
                        border = BorderStroke(
                            if (unassignedSelected) 2.dp else 1.dp,
                            if (unassignedSelected) {
                                ArmyristColors.PrimaryControl
                            } else {
                                ArmyristColors.Border
                            }
                        )
                    ) {
                        Text(
                            "미지정",
                            modifier = Modifier.padding(
                                horizontal = 10.dp,
                                vertical = 8.dp
                            ),
                            fontWeight =
                                if (unassignedSelected) {
                                    FontWeight.Bold
                                } else {
                                    FontWeight.Medium
                                }
                        )
                    }

                    sheet.groups
                        .sortedBy { it.order }
                        .forEach { group ->
                            val color = parseColor(group.color)
                            val selected = groupId == group.id

                            Surface(
                                onClick = { groupId = group.id },
                                shape = ArmyristPanelShape,
                                color = color.copy(
                                    alpha =
                                        if (selected) 0.28f else 0.12f
                                ),
                                border = BorderStroke(
                                    if (selected) 2.dp else 1.dp,
                                    color.copy(
                                        alpha =
                                            if (selected) 0.95f else 0.62f
                                    )
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(
                                        horizontal = 9.dp,
                                        vertical = 7.dp
                                    ),
                                    verticalAlignment =
                                        Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier
                                            .size(10.dp)
                                            .background(
                                                color,
                                                ArmyristPanelShape
                                            )
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        group.name,
                                        maxLines = 1,
                                        fontWeight =
                                            if (selected) {
                                                FontWeight.Bold
                                            } else {
                                                FontWeight.Medium
                                            }
                                    )
                                }
                            }
                        }
                }

                if (error.isNotBlank()) {
                    Text(
                        error,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val quantity =
                        if (item == null) {
                            DomainRules.parseQuantity(quantityRaw)
                        } else {
                            item.quantity
                        }

                    when {
                        name.trim().isEmpty() ->
                            error = "항목명을 입력하세요."

                        unit.trim().isEmpty() ->
                            error = "단위를 입력하세요."

                        quantity == null ->
                            error = "수량은 0 이상의 정수만 가능합니다."

                        else -> {
                            done(
                                ItemDraft(
                                    name = name.trim(),
                                    quantity = quantity,
                                    unit = unit.trim(),
                                    note = note.trim(),
                                    groupId = groupId
                                )
                            )
                        }
                    }
                },
                shape = ArmyristPanelShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArmyristColors.PrimaryControl,
                    contentColor = ArmyristColors.OnDark
                )
            ) {
                Text(
                    "확인",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = { done(null) },
                shape = ArmyristPanelShape,
                border = BorderStroke(
                    1.dp,
                    ArmyristColors.Border
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = ArmyristColors.WorkSurface,
                    contentColor = ArmyristColors.PrimaryText
                )
            ) {
                Text("취소")
            }
        }
    )
}

@Composable
private fun QuantityDialog(
    current: Int,
    done: (Int?) -> Unit
) {
    var raw by remember { mutableStateOf(current.toString()) }
    var error by remember { mutableStateOf("") }

    ArmyristDialog(
        onDismissRequest = { done(null) },
        title = { Text("수량 직접 입력") },
        text = {
            Column {
                OutlinedTextField(
                    value = raw,
                    onValueChange = { raw = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    )
                )
                if (error.isNotBlank()) {
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val parsed = DomainRules.parseQuantity(raw)
                    if (parsed == null) {
                        error = "0 이상의 정수를 입력하세요."
                    } else {
                        done(parsed)
                    }
                }
            ) {
                Text("확인")
            }
        },
        dismissButton = {
            TextButton(onClick = { done(null) }) {
                Text("취소")
            }
        }
    )
}

@Composable
private fun CountingGroupManagerDialog(
    sheet: CountingSheet,
    onAdd: (String, String, Boolean) -> Unit,
    onRename: (String, String, String, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var create by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf<CountingGroup?>(null) }
    var delete by remember { mutableStateOf<CountingGroup?>(null) }

    ArmyristDialog(
        onDismissRequest = onDismiss,
        shape = ArmyristPanelShape,
        containerColor = ArmyristColors.WorkSurface,
        title = {
            Text(
                "그룹 관리",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                if (sheet.groups.isEmpty()) {
                    Text(
                        "그룹이 없습니다.",
                        color = ArmyristColors.SecondaryText,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 340.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(
                            sheet.groups.sortedBy { it.order },
                            key = { it.id }
                        ) { group ->
                            val color = parseColor(group.color)
                            Surface(
                                onClick = { rename = group },
                                color = color.copy(alpha = 0.12f),
                                shape = ArmyristPanelShape,
                                border = BorderStroke(
                                    1.dp,
                                    color.copy(alpha = 0.65f)
                                )
                            ) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment =
                                            Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier
                                                .size(18.dp)
                                                .background(
                                                    color,
                                                    CircleShape
                                                )
                                        )
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                group.name,
                                                fontWeight =
                                                    FontWeight.SemiBold
                                            )
                                            Text(
                                                if (group.showAggregate) {
                                                    "합계 표시"
                                                } else {
                                                    "합계 숨김"
                                                },
                                                style =
                                                    MaterialTheme.typography
                                                        .bodySmall,
                                                color =
                                                    ArmyristColors
                                                        .SecondaryText
                                            )
                                        }
                                        TextButton(
                                            onClick = { rename = group }
                                        ) {
                                            Text("편집")
                                        }
                                        TextButton(
                                            onClick = { delete = group }
                                        ) {
                                            Text("삭제")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { create = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = ArmyristPanelShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArmyristColors.PrimaryControl,
                        contentColor = ArmyristColors.OnDark
                    )
                ) {
                    Text("+ 그룹 추가")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("닫기")
            }
        }
    )

    if (create) {
        GroupEditDialog(
            title = "그룹 추가",
            initialName = "",
            initialColor = "#596B45",
            initialShowAggregate = true
        ) { name, color, showAggregate ->
            create = false
            if (name != null) {
                onAdd(name, color, showAggregate)
            }
        }
    }

    rename?.let { group ->
        GroupEditDialog(
            title = "그룹 편집",
            initialName = group.name,
            initialColor = group.color,
            initialShowAggregate = group.showAggregate
        ) { name, color, showAggregate ->
            rename = null
            if (name != null) {
                onRename(
                    group.id,
                    name,
                    color,
                    showAggregate
                )
            }
        }
    }

    delete?.let { group ->
        ArmyristDialog(
            onDismissRequest = { delete = null },
            title = { Text("그룹 삭제") },
            text = {
                Text(
                    "이 그룹의 항목은 삭제되지 않고 미지정으로 변경됩니다. " +
                        "관련 계산은 삭제됩니다."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete(group.id)
                        delete = null
                    }
                ) {
                    Text("삭제")
                }
            },
            dismissButton = {
                TextButton(onClick = { delete = null }) {
                    Text("취소")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroupScreen(
    sheet: CountingSheet,
    onBack: () -> Unit,
    onAdd: (String, String, Boolean) -> Unit,
    onRename: (String, String, String, Boolean) -> Unit,
    onDelete: (String) -> Unit
) {
    var create by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf<CountingGroup?>(null) }
    var delete by remember { mutableStateOf<CountingGroup?>(null) }

    BackHandler { onBack() }

    Scaffold(
        topBar = {
            ArmyristTopBar(
                title = "그룹 관리",
                subtitle = "COUNTING · GROUP",
                leadingLabel = "뒤로",
                onLeading = onBack
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { create = true }) {
                Text("그룹 추가")
            }
        }
    ) { padding ->
        if (sheet.groups.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("그룹이 없습니다.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(sheet.groups.sortedBy { it.order }) { group ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = parseColor(group.color).copy(alpha = 0.12f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(18.dp)
                                    .background(parseColor(group.color), CircleShape)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    group.name,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (group.showAggregate) {
                                        "합계 표시"
                                    } else {
                                        "합계 숨김"
                                    },
                                    style =
                                        MaterialTheme.typography.bodySmall,
                                    color =
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { rename = group }) {
                                Text("편집")
                            }
                            TextButton(onClick = { delete = group }) {
                                Text("삭제")
                            }
                        }
                    }
                }
            }
        }
    }

    if (create) {
        GroupEditDialog(
            title = "그룹 추가",
            initialName = "",
            initialColor = "#596B45",
            initialShowAggregate = true
        ) { name, color, showAggregate ->
            create = false
            if (name != null) {
                onAdd(name, color, showAggregate)
            }
        }
    }

    rename?.let { group ->
        GroupEditDialog(
            title = "그룹 편집",
            initialName = group.name,
            initialColor = group.color,
            initialShowAggregate = group.showAggregate
        ) { name, color, showAggregate ->
            rename = null
            if (name != null) {
                onRename(
                    group.id,
                    name,
                    color,
                    showAggregate
                )
            }
        }
    }

    delete?.let { group ->
        val itemCount = sheet.items.count { it.groupId == group.id }
        val calculationCount = sheet.calculations.count {
            it.leftGroupId == group.id || it.rightGroupId == group.id
        }

        ConfirmDialog(
            title = "그룹 삭제",
            message = "항목 ${itemCount}개는 삭제되지 않고 '미지정'으로 변경됩니다. " +
                "관련 계산 ${calculationCount}개는 삭제됩니다."
        ) {
            delete = null
            if (it) onDelete(group.id)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CalculationScreen(
    sheet: CountingSheet,
    onBack: () -> Unit,
    onAdd: (String, CalculationOperator, String, String) -> Unit,
    onEdit: (String, String, CalculationOperator, String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var editor by remember { mutableStateOf<GroupCalculation?>(null) }
    var creating by rememberSaveable { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<GroupCalculation?>(null) }

    BackHandler { onBack() }

    Scaffold(
        topBar = {
            ArmyristTopBar(
                title = "그룹 계산",
                subtitle = "COUNTING · CALCULATION",
                leadingLabel = "뒤로",
                onLeading = onBack
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { creating = true }) {
                Text("계산 추가")
            }
        }
    ) { padding ->
        when {
            sheet.groups.isEmpty() -> {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("먼저 그룹을 만들어 주세요.")
                }
            }

            sheet.calculations.isEmpty() -> {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("등록된 계산이 없습니다.")
                }
            }

            else -> {
                LazyColumn(
                    modifier = Modifier.padding(padding),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(sheet.calculations) { calculation ->
                        val leftName = sheet.groups.firstOrNull {
                            it.id == calculation.leftGroupId
                        }?.name ?: "?"
                        val rightName = sheet.groups.firstOrNull {
                            it.id == calculation.rightGroupId
                        }?.name ?: "?"
                        val symbol =
                            if (calculation.operator == CalculationOperator.ADD) "+" else "−"

                        val leftTotals = DomainRules.aggregate(
                            sheet.items.filter {
                                it.groupId == calculation.leftGroupId
                            }
                        )
                        val rightTotals = DomainRules.aggregate(
                            sheet.items.filter {
                                it.groupId == calculation.rightGroupId
                            }
                        )
                        val result = DomainRules.calculate(
                            leftTotals,
                            calculation.operator,
                            rightTotals
                        )

                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    calculation.name.ifBlank {
                                        "$leftName $symbol $rightName"
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                                Text("$leftName $symbol $rightName")
                                result.forEach { (unit, quantity) ->
                                    Text("$unit : $quantity")
                                }
                                Row {
                                    TextButton(onClick = { editor = calculation }) {
                                        Text("편집")
                                    }
                                    TextButton(onClick = { deleteTarget = calculation }) {
                                        Text("삭제")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        CalculationDialog(sheet, null) { draft ->
            creating = false
            draft?.let {
                onAdd(it.left, it.op, it.right, it.name)
            }
        }
    }

    editor?.let { calculation ->
        CalculationDialog(sheet, calculation) { draft ->
            editor = null
            draft?.let {
                onEdit(
                    calculation.id,
                    it.left,
                    it.op,
                    it.right,
                    it.name
                )
            }
        }
    }

    deleteTarget?.let { calculation ->
        ConfirmDialog(
            title = "계산 삭제",
            message = "이 계산을 삭제합니다."
        ) {
            deleteTarget = null
            if (it) onDelete(calculation.id)
        }
    }
}

private data class CalcDraft(
    val left: String,
    val op: CalculationOperator,
    val right: String,
    val name: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CalculationDialog(
    sheet: CountingSheet,
    current: GroupCalculation?,
    done: (CalcDraft?) -> Unit
) {
    if (sheet.groups.isEmpty()) {
        done(null)
        return
    }

    var left by remember {
        mutableStateOf(current?.leftGroupId ?: sheet.groups.first().id)
    }
    var right by remember {
        mutableStateOf(current?.rightGroupId ?: sheet.groups.first().id)
    }
    var operator by remember {
        mutableStateOf(current?.operator ?: CalculationOperator.ADD)
    }
    var name by remember {
        mutableStateOf(current?.name ?: "")
    }

    val scrollState = rememberScrollState()

    val selectedChipColors = FilterChipDefaults.filterChipColors(
        containerColor = ArmyristColors.RaisedSurface,
        labelColor = ArmyristColors.PrimaryText,
        selectedContainerColor = ArmyristColors.PrimaryControl,
        selectedLabelColor = ArmyristColors.OnDark
    )

    ArmyristDialog(
        onDismissRequest = { done(null) },
        shape = ArmyristPanelShape,
        containerColor = ArmyristColors.WorkSurface,
        titleContentColor = ArmyristColors.PrimaryText,
        textContentColor = ArmyristColors.PrimaryText,
        title = {
            Column {
                Text(
                    if (current == null) "계산 추가" else "계산 편집",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "COUNTING · CALCULATION",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArmyristColors.SecondaryText
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("왼쪽 그룹", fontWeight = FontWeight.SemiBold)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    sheet.groups.sortedBy { it.order }.forEach { group ->
                        val selected = left == group.id
                        FilterChip(
                            selected = selected,
                            onClick = { left = group.id },
                            label = {
                                Text(
                                    group.name,
                                    fontWeight = if (selected) {
                                        FontWeight.Bold
                                    } else {
                                        FontWeight.Medium
                                    }
                                )
                            },
                            colors = selectedChipColors,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = ArmyristColors.Border,
                                selectedBorderColor = ArmyristColors.PrimaryControl,
                                borderWidth = 1.dp,
                                selectedBorderWidth = 2.dp
                            )
                        )
                    }
                }

                HorizontalDivider(color = ArmyristColors.Divider)

                Text("연산", fontWeight = FontWeight.SemiBold)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    val addSelected = operator == CalculationOperator.ADD
                    FilterChip(
                        selected = addSelected,
                        onClick = { operator = CalculationOperator.ADD },
                        label = { Text("+", fontWeight = FontWeight.Bold) },
                        colors = selectedChipColors,
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = addSelected,
                            borderColor = ArmyristColors.Border,
                            selectedBorderColor = ArmyristColors.PrimaryControl,
                            borderWidth = 1.dp,
                            selectedBorderWidth = 2.dp
                        )
                    )

                    val subtractSelected =
                        operator == CalculationOperator.SUBTRACT
                    FilterChip(
                        selected = subtractSelected,
                        onClick = {
                            operator = CalculationOperator.SUBTRACT
                        },
                        label = { Text("−", fontWeight = FontWeight.Bold) },
                        colors = selectedChipColors,
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = subtractSelected,
                            borderColor = ArmyristColors.Border,
                            selectedBorderColor = ArmyristColors.PrimaryControl,
                            borderWidth = 1.dp,
                            selectedBorderWidth = 2.dp
                        )
                    )
                }

                HorizontalDivider(color = ArmyristColors.Divider)

                Text("오른쪽 그룹", fontWeight = FontWeight.SemiBold)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    sheet.groups.sortedBy { it.order }.forEach { group ->
                        val selected = right == group.id
                        FilterChip(
                            selected = selected,
                            onClick = { right = group.id },
                            label = {
                                Text(
                                    group.name,
                                    fontWeight = if (selected) {
                                        FontWeight.Bold
                                    } else {
                                        FontWeight.Medium
                                    }
                                )
                            },
                            colors = selectedChipColors,
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = ArmyristColors.Border,
                                selectedBorderColor = ArmyristColors.PrimaryControl,
                                borderWidth = 1.dp,
                                selectedBorderWidth = 2.dp
                            )
                        )
                    }
                }

                HorizontalDivider(color = ArmyristColors.Divider)

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("계산명 (선택)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = ArmyristColors.InputSurface,
                        unfocusedContainerColor = ArmyristColors.InputSurface,
                        focusedBorderColor = ArmyristColors.PrimaryControl,
                        unfocusedBorderColor = ArmyristColors.Border
                    )
                )

                Spacer(Modifier.height(2.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    done(
                        CalcDraft(
                            left = left,
                            op = operator,
                            right = right,
                            name = name.trim()
                        )
                    )
                },
                shape = ArmyristPanelShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArmyristColors.PrimaryControl,
                    contentColor = ArmyristColors.OnDark
                )
            ) {
                Text("확인", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = { done(null) },
                shape = ArmyristPanelShape,
                border = BorderStroke(1.dp, ArmyristColors.Border),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = ArmyristColors.WorkSurface,
                    contentColor = ArmyristColors.PrimaryText
                )
            ) {
                Text("취소")
            }
        }
    )
}

private val GROUP_COLORS = listOf(
    "#596B45",
    "#006C4C",
    "#9C4238",
    "#0061A4",
    "#7D5260",
    "#6B5E00",
    "#725188",
    "#3F6374"
)

private fun parseColor(hex: String): Color {
    return runCatching {
        Color(android.graphics.Color.parseColor(hex))
    }.getOrDefault(Color(0xFF596B45))
}

@Composable
private fun GroupEditDialog(
    title: String,
    initialName: String,
    initialColor: String,
    initialShowAggregate: Boolean,
    done: (String?, String, Boolean) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var color by remember { mutableStateOf(initialColor) }
    var showAggregate by remember {
        mutableStateOf(initialShowAggregate)
    }
    var error by remember { mutableStateOf("") }

    ArmyristDialog(
        onDismissRequest = {
            done(null, color, showAggregate)
        },
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("그룹명") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(14.dp))
                Text("그룹 색상")
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GROUP_COLORS.take(4).forEach { candidate ->
                        ColorDot(
                            color = candidate,
                            selected = color == candidate,
                            onClick = { color = candidate }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GROUP_COLORS.drop(4).forEach { candidate ->
                        ColorDot(
                            color = candidate,
                            selected = color == candidate,
                            onClick = { color = candidate }
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "합계 표시",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "그룹 일반 합계를 화면/전달문에 표시합니다.",
                            style = MaterialTheme.typography.bodySmall,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = showAggregate,
                        onCheckedChange = {
                            showAggregate = it
                        }
                    )
                }

                if (error.isNotBlank()) {
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.trim().isEmpty()) {
                        error = "그룹명을 입력하세요."
                    } else {
                        done(
                            name.trim(),
                            color,
                            showAggregate
                        )
                    }
                }
            ) {
                Text("확인")
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    done(null, color, showAggregate)
                }
            ) {
                Text("취소")
            }
        }
    )
}

@Composable
private fun ColorDot(
    color: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(if (selected) 38.dp else 34.dp)
            .clickable(onClick = onClick),
        shape = CircleShape,
        color = parseColor(color),
        tonalElevation = if (selected) 6.dp else 0.dp
    ) {
        if (selected) {
            Box(contentAlignment = Alignment.Center) {
                Text("✓", color = Color.White)
            }
        }
    }
}

@Composable
private fun GroupPickerDialog(
    sheet: CountingSheet,
    done: (String?) -> Unit
) {
    ArmyristDialog(
        onDismissRequest = { done(null) },
        shape = ArmyristPanelShape,
        containerColor = ArmyristColors.WorkSurface,
        titleContentColor = ArmyristColors.PrimaryText,
        textContentColor = ArmyristColors.PrimaryText,
        title = {
            Column {
                Text(
                    "그룹 지정",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "지정할 그룹을 선택하세요.",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArmyristColors.SecondaryText
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = ArmyristColors.RaisedSurface,
                    shape = ArmyristPanelShape,
                    border = BorderStroke(
                        1.dp,
                        ArmyristColors.Border
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { done("__UNASSIGNED__") }
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(
                                horizontal = 14.dp,
                                vertical = 14.dp
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(16.dp)
                                .background(
                                    ArmyristColors.Divider,
                                    CircleShape
                                )
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "미지정",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                sheet.groups
                    .sortedBy { it.order }
                    .forEach { group ->
                        val color = parseColor(group.color)

                        Surface(
                            color = color.copy(alpha = 0.13f),
                            shape = ArmyristPanelShape,
                            border = BorderStroke(
                                1.dp,
                                color.copy(alpha = 0.72f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { done(group.id) }
                        ) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        horizontal = 14.dp,
                                        vertical = 14.dp
                                    ),
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier
                                        .size(16.dp)
                                        .background(
                                            color,
                                            CircleShape
                                        )
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    group.name,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = { done(null) }) {
                Text("취소")
            }
        }
    )
}

@Composable
private fun TextInputDialog(
    title: String,
    initial: String,
    helper: String,
    allowEmpty: Boolean = false,
    singleLine: Boolean = true,
    done: (String?) -> Unit
) {
    var value by remember { mutableStateOf(initial) }
    var error by remember { mutableStateOf("") }

    ArmyristDialog(
        onDismissRequest = { done(null) },
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    singleLine = singleLine,
                    modifier = Modifier.fillMaxWidth()
                )
                if (helper.isNotBlank()) {
                    Text(
                        helper,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (error.isNotBlank()) {
                    Text(
                        error,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (!allowEmpty && value.trim().isEmpty()) {
                        error = "빈 값은 저장할 수 없습니다."
                    } else {
                        done(value)
                    }
                }
            ) {
                Text("확인")
            }
        },
        dismissButton = {
            TextButton(onClick = { done(null) }) {
                Text("취소")
            }
        }
    )
}

@Composable
private fun ConfirmDialog(
    title: String,
    message: String,
    done: (Boolean) -> Unit
) {
    ArmyristDialog(
        onDismissRequest = { done(false) },
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = { done(true) }) {
                Text("확인")
            }
        },
        dismissButton = {
            TextButton(onClick = { done(false) }) {
                Text("취소")
            }
        }
    )
}
