package com.seolhwa.armyrist

import com.seolhwa.armyrist.calendar.CalendarActivity
import com.seolhwa.armyrist.calendar.HomeCalendarCard
import androidx.compose.material.icons.outlined.CalendarMonth
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.seolhwa.armyrist.home.HomeToolGrid
import com.seolhwa.armyrist.home.HomeBannerCard
import com.seolhwa.armyrist.home.HomeBannerPreferences
import com.seolhwa.armyrist.home.HomeBannerMode
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FormatListNumbered
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PhoneInTalk
import com.seolhwa.armyrist.handicap.HandicapActivity
import androidx.compose.ui.graphics.vector.ImageVector
import com.seolhwa.armyrist.update.ArmyristUpdateManager
import com.seolhwa.armyrist.update.AutoUpdateCheckHost
import com.seolhwa.armyrist.update.UpdateReleaseMetadata

class HomeActivity : ComponentActivity() {
    private var homeRevision by mutableIntStateOf(0)
    private var homeAvailableUpdate by mutableStateOf<UpdateReleaseMetadata?>(null)

    override fun onResume() {
        super.onResume()
        homeRevision++
        homeAvailableUpdate = ArmyristUpdateManager(this).knownAvailable()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (
            NearbyConnectionsPoC.isReceiveEnabled(this) &&
            NearbyPermissionGate.hasRequiredPermissions(this)
        ) {
            NearbyConnectionsPoC.startReceiverService(this)
        }

        setContent {
            ArmyristTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ArmyristColors.AppBackground
                ) {
                    HomeScreen(
                        revision = homeRevision,
                        onCounting = {
                            startActivity(Intent(this, MainActivity::class.java))
                        },
                        onChecklist = {
                            startActivity(Intent(this, ChecklistActivity::class.java))
                        },
                        onTimePlan = {
                            startActivity(Intent(this, TimePlanActivity::class.java))
                        },
                        onReportTemplate = {
                            startActivity(Intent(this, ReportTemplateActivity::class.java))
                        },
                        onHandicap = { startActivity(Intent(this, HandicapActivity::class.java)) },
                        onUserProfile = {
                            startActivity(Intent(this, UserProfileActivity::class.java))
                        },
                        onDataManagement = {
                            startActivity(
                                Intent(
                                    this,
                                    DataManagementActivity::class.java
                                )
                            )
                        },
                        availableUpdate = homeAvailableUpdate,
                        onUpdateAvailabilityChanged = { homeAvailableUpdate = it }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    revision: Int,
    onCounting: () -> Unit,
    onChecklist: () -> Unit,
    onTimePlan: () -> Unit,
    onReportTemplate: () -> Unit,
    onHandicap: () -> Unit,
    onUserProfile: () -> Unit,
    onDataManagement: () -> Unit,
    availableUpdate: UpdateReleaseMetadata?,
    onUpdateAvailabilityChanged: (UpdateReleaseMetadata?) -> Unit
) {
    AutoUpdateCheckHost(onUpdateAvailabilityChanged = onUpdateAvailabilityChanged)
    val context = LocalContext.current
    val bannerPreferences = remember(context) { HomeBannerPreferences(context) }
    val bannerConfig = remember(revision) { bannerPreferences.load() }
    if(bannerConfig.compactHome) {
        com.seolhwa.armyrist.home.CompactHome(revision,bannerConfig,onTool={id->when(id){
            "counting"->onCounting();"checklist"->onChecklist();"timeplan"->onTimePlan();"report"->onReportTemplate();"handicap"->onHandicap();else->context.startActivity(Intent(context,CalendarActivity::class.java))
        }},onSettings=onUserProfile,onData=onDataManagement)
        return
    }
    val homeListState = rememberLazyListState()
    var homeViewport by remember { mutableStateOf(Rect.Zero) }


    LazyColumn(
        state = homeListState,
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .onGloballyPositioned { homeViewport = it.boundsInRoot() },
        contentPadding = PaddingValues(
            start = 14.dp,
            end = 14.dp,
            top = 12.dp,
            bottom = 28.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                ArmyristHelpButton(ArmyristHelpTopic.HOME)
            }
        }
        if (bannerConfig.calendarEnabled) {
            item { HomeCalendarCard(revision) { date -> context.startActivity(Intent(context, CalendarActivity::class.java).putExtra("calendarDate", date.toString())) } }
        }
        if (bannerConfig.mode != HomeBannerMode.HIDDEN) {
            item {
                var expanded by remember { mutableStateOf(bannerConfig.mode == HomeBannerMode.NOTICE) }
                Column {
                    TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "계획 배너 접기 ∧" else "현재 계획·다음 실시사항 보기 ∨") }
                    if (expanded) HomeBannerCard(bannerConfig, onTimePlan, onUserProfile)
                }
            }
        }
        item { ArmyristSectionLabel("업무 도구 · 길게 눌러 배치 변경") }
        item {
            HomeToolGrid(homeListState, homeViewport) { id, modifier, dragging ->
                val action = when (id) {
                    "counting" -> onCounting
                    "checklist" -> onChecklist
                    "timeplan" -> onTimePlan
                    "calendar" -> { { context.startActivity(Intent(context, CalendarActivity::class.java)) } }
                    "report" -> onReportTemplate
                    else -> onHandicap
                }
                val title = when (id) { "counting" -> "실셈"; "checklist" -> "체크리스트"; "timeplan" -> "시간계획"; "calendar" -> "달력"; "report" -> "보고 양식"; else -> "핸디캡 상황" }
                val subtitle = when (id) { "counting" -> "수량 기록과 집계"; "checklist" -> "점검과 진행 현황"; "timeplan" -> "일정과 실시사항"; "calendar" -> "모든 일정 한눈에 보기"; "report" -> "결과 작성과 공유"; else -> "단어 선택과 연락 안내" }
                val icon = when (id) { "counting" -> Icons.Outlined.FormatListNumbered; "checklist" -> Icons.Outlined.FactCheck; "timeplan" -> Icons.Outlined.Schedule; "calendar" -> Icons.Outlined.CalendarMonth; "report" -> Icons.Outlined.Description; else -> Icons.Outlined.PhoneInTalk }
                HomeToolPanel(title, subtitle, icon, { if (!dragging) action() }, modifier)
            }
        }

        item { ArmyristSectionLabel("설정") }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onUserProfile),
                color = ArmyristColors.WorkSurface,
                shape = ArmyristPanelShape,
                border = BorderStroke(1.dp, ArmyristColors.Border)
            ) {
                val updatePulse =
                    if (availableUpdate != null) {
                        val transition = rememberInfiniteTransition(label = "home-update-pulse")
                        transition.animateFloat(
                            initialValue = 0.58f,
                            targetValue = 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(durationMillis = 1400),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "home-update-alpha"
                        ).value
                    } else {
                        1f
                    }

                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "설정 · 내 정보",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (availableUpdate != null) {
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "새 업데이트 발견",
                                modifier = Modifier.alpha(updatePulse),
                                style = MaterialTheme.typography.labelMedium,
                                color = ArmyristColors.PrimaryControl,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Text(
                        if (availableUpdate != null) {
                            "사용자 · 앱 정보 · ${availableUpdate.versionName}  ›"
                        } else {
                            "사용자 · 홈 배너 · 앱 정보  ›"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = ArmyristColors.SecondaryText
                    )
                }
            }
        }

        item { NearbyReceiveToggle() }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onDataManagement),
                color = ArmyristColors.WorkSurface,
                shape = ArmyristPanelShape,
                border = BorderStroke(1.dp, ArmyristColors.Border)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "데이터 관리",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "백업 · 복원  ›",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArmyristColors.SecondaryText
                    )
                }
            }
        }

        item {
            ArmyristSystemLabel(
                "모든 기록은 이 기기에 보관됩니다",
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun NearbyReceiveToggle() {
    val context = LocalContext.current
    var enabled by remember {
        mutableStateOf(
            NearbyConnectionsPoC.isReceiveEnabled(context)
        )
    }
    var starting by remember { mutableStateOf(false) }
    var message by remember {
        mutableStateOf(
            if (enabled) "● 수신 대기 중" else "수신 모드가 꺼져 있습니다."
        )
    }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    NearbyConnectionsPoC.ACTION_ADVERTISING_ACTIVE -> {
                        starting = false
                        enabled = true
                        message = "● 수신 대기 중"
                    }

                    NearbyConnectionsPoC.ACTION_ADVERTISING_FAILED -> {
                        starting = false
                        enabled = false
                        message =
                            "주변 데이터 수신을 시작하지 못했습니다. 권한과 무선 연결 상태를 확인해주세요."
                    }
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(NearbyConnectionsPoC.ACTION_ADVERTISING_ACTIVE)
            addAction(NearbyConnectionsPoC.ACTION_ADVERTISING_FAILED)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(
                receiver,
                filter,
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }

        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    val launcher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            val granted = NearbyPermissionGate.hasRequiredPermissions(context)

            if (granted) {
                starting = true
                enabled = false
                message = "수신 대기를 시작하는 중…"
                NearbyConnectionsPoC.startReceiverService(context)
            } else {
                NearbyConnectionsPoC.setReceiveEnabled(context, false)
                starting = false
                enabled = false
                message =
                    "주변 데이터 수신을 사용하려면 근처 기기 권한이 필요합니다."
            }
        }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ArmyristColors.WorkSurface,
        shape = ArmyristPanelShape,
        border = BorderStroke(1.dp, ArmyristColors.Border)
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = 14.dp,
                vertical = 11.dp
            )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "주변 데이터 수신",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        message,
                        style = MaterialTheme.typography.bodySmall,
                        color =
                            if (enabled) {
                                ArmyristColors.PrimaryControl
                            } else {
                                ArmyristColors.SecondaryText
                            }
                    )
                }

                Switch(
                    checked = enabled,
                    enabled = !starting,
                    onCheckedChange = { turnOn ->
                        if (!turnOn) {
                            NearbyConnectionsPoC.stopReceiverService(context)
                            starting = false
                            enabled = false
                            message = "수신 모드가 꺼져 있습니다."
                        } else if (
                            NearbyPermissionGate.hasRequiredPermissions(context)
                        ) {
                            starting = true
                            enabled = false
                            message = "수신 대기를 시작하는 중…"
                            NearbyConnectionsPoC.startReceiverService(context)
                        } else {
                            launcher.launch(
                                NearbyPermissionGate.missingPermissions(context)
                            )
                        }
                    }
                )
            }

            if (enabled) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "낄롬리스를 보고 있지 않아도 주변 전송 요청을 받을 수 있도록 수신 서비스를 유지합니다.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ArmyristColors.SecondaryText
                )
            }
        }
    }
}

@Composable
private fun HomeToolPanel(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.heightIn(min = 148.dp).clickable(onClick = onClick),
        color = ArmyristColors.RaisedSurface,
        shape = ArmyristPanelShape,
        border = BorderStroke(1.dp, ArmyristColors.SoftBorder)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(color = ArmyristColors.SecondaryControl, shape = ArmyristControlShape) {
                Icon(icon, contentDescription = null, tint = ArmyristColors.PrimaryControl,
                    modifier = Modifier.padding(10.dp).size(24.dp))
            }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ArmyristColors.SecondaryText)
        }
    }
}
